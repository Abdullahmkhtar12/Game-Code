let currentGame="";
function openForm(game){
currentGame=game;
document.getElementById("formSection").classList.remove("hidden");
let title=document.getElementById("gameTitle");
let amount=document.getElementById("amount");
amount.innerHTML="";
if(game==="freefire"){title.innerText="شحن فري فاير";addOptions(["100 جوهرة","310 جوهرة","520 جوهرة","1060 جوهرة"]);}
if(game==="pubg"){title.innerText="شحن شدات ببجي";addOptions(["60 UC","325 UC","660 UC","1800 UC"]);}
if(game==="visa"){title.innerText="بطاقات فيزا / ماستر كارد";addOptions(["10$","25$","50$"]);}
}
function addOptions(list){
let select=document.getElementById("amount");
list.forEach(item=>{let option=document.createElement("option");option.text=item;select.add(option);});
}
function sendOrder(){
let id=document.getElementById("playerId").value;
let amount=document.getElementById("amount").value;
let payment=document.getElementById("payment").value;
let message=`طلب شحن جديد 🔥
اللعبة: ${currentGame}
الحساب: ${id}
الباقة: ${amount}
طريقة الدفع: ${payment}

تم التحويل على:
فوري: 51612876
ماي كاش: 401762443`;
let phone="218931831472";
let url=`https://wa.me/${phone}?text=${encodeURIComponent(message)}`;
window.open(url,"_blank");
}
